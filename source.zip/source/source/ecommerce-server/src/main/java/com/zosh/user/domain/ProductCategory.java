package com.zosh.user.domain;

public enum ProductCategory {

	MALE,
	FEMALE
}
